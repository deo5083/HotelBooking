/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelbooking.models;

/**
 *
 * @author David Ortiz
 */
public interface Details {
    
    public abstract void printDetails(); 
    

}
